import { Router, Request, Response, NextFunction } from 'express';
import { repository } from './db/repository.js';
import { workflowEngine } from './services/workflowEngine.service.js';
import { goLoginService } from './services/gologin.service.js';
import { telegramNotificationService } from './services/telegram.service.js';
import { microsoftGraphService } from './services/microsoftGraph.service.js';
import { googleSheetsService } from './services/googleSheets.service.js';
import { retryEngine } from './services/retryEngine.service.js';
import { requireRole } from './middleware/auth.js';
import { Job, SystemSettings } from './types.js';
import { sanitizeJob, sanitizeHumanTask, sanitizeSession } from './utils/sanitizer.js';
import { logger } from './utils/logger.js';
import { lockManager } from './utils/concurrencyLock.js';
import { globalApiLimiter, mutationRateLimiter } from './middleware/rateLimiter.js';
import { idempotencyMiddleware } from './middleware/idempotency.js';
import {
  validateBody,
  CreateJobSchema,
  CompleteHumanTaskSchema,
  UpdateSettingsSchema,
  CreateOperatorSchema,
  UpdateOperatorSchema,
  UpdateRetryPolicySchema,
} from './validators/schemas.js';
import { authRouter, adminRouter } from './adminRoutes.js';

export const apiRouter = Router();

// Apply global rate limiting and idempotency middleware
apiRouter.use(globalApiLimiter);
apiRouter.use(idempotencyMiddleware);

// Authentication and Admin Routes
apiRouter.use('/auth', authRouter);
apiRouter.use('/admin', adminRouter);

// ==========================================
// 1. DASHBOARD & HEALTH CHECKS
// ==========================================
apiRouter.get('/dashboard/metrics', (req: Request, res: Response, next: NextFunction) => {
  try {
    const metrics = repository.getDashboardMetrics();
    res.json(metrics);
  } catch (err) {
    next(err);
  }
});

// Liveness check
apiRouter.get('/health', (req: Request, res: Response) => {
  const integrations = repository.getIntegrations();
  const settings = repository.getSettings();
  res.json({
    status: 'HEALTHY',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    mockMode: settings.mockMode,
    integrations,
  });
});

// Deep readiness check
apiRouter.get('/ready', (req: Request, res: Response) => {
  const mem = process.memoryUsage();
  const uptime = process.uptime();
  const settings = repository.getSettings();
  const queueStats = repository.getJobs({ status: 'QUEUED' }).total;

  res.status(200).json({
    status: 'READY',
    uptimeSeconds: Math.floor(uptime),
    memory: {
      rssMb: Math.round(mem.rss / 1024 / 1024),
      heapUsedMb: Math.round(mem.heapUsed / 1024 / 1024),
    },
    system: {
      mockMode: settings.mockMode,
      maintenanceMode: settings.maintenanceMode,
      queueSize: queueStats,
      concurrencyLimit: settings.concurrencyLimit,
    },
    timestamp: new Date().toISOString(),
  });
});

apiRouter.get('/integrations/status', (req: Request, res: Response) => {
  res.json(repository.getIntegrations());
});

// ==========================================
// 2. JOBS (SANITIZED & PROTECTED)
// ==========================================
apiRouter.get('/jobs', (req: Request, res: Response, next: NextFunction) => {
  try {
    const { status, operatorId, search, priority, limit, offset } = req.query;
    const parsedLimit = limit ? parseInt(limit as string, 10) : 50;
    const parsedOffset = offset ? parseInt(offset as string, 10) : 0;

    const result = repository.getJobs({
      status: status as string,
      operatorId: operatorId as string,
      search: search as string,
      priority: priority as string,
      limit: parsedLimit,
      offset: parsedOffset,
    });

    // Strip sensitive passwords & proxy credentials from frontend payload
    res.json({
      items: result.items.map(sanitizeJob),
      total: result.total,
      limit: parsedLimit,
      offset: parsedOffset,
      page: Math.floor(parsedOffset / parsedLimit) + 1,
      totalPages: Math.ceil(result.total / parsedLimit),
    });
  } catch (err) {
    next(err);
  }
});

apiRouter.post(
  '/jobs',
  mutationRateLimiter,
  requireRole('ADMIN', 'SUPERVISOR', 'OPERATOR'),
  validateBody(CreateJobSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { shopName, email, passwordReference, proxyReference, priority, runMode, autoStart, tags, notes } = req.body;

      // 1. Protection against duplicate jobs
      const dupCheck = workflowEngine.checkDuplicateJob(shopName, email);
      if (dupCheck.isDuplicate) {
        logger.warn('JobCreation', `Duplicate job rejected for shop ${shopName} or email ${email}`);
        return res.status(409).json({
          error: `An active job (${dupCheck.existingJob?.jobId}) already exists for shop '${shopName}' or email '${email}'. Duplicate jobs are rejected.`,
          code: 'DUPLICATE_JOB_CONFLICT',
          existingJobId: dupCheck.existingJob?.jobId,
        });
      }

      const settings = repository.getSettings();
      if (settings.queueLimit !== null) {
        const currentQueue = repository.getJobs({ status: 'QUEUED' }).total;
        if (currentQueue >= settings.queueLimit) {
          return res.status(429).json({
            error: `Queue capacity limit of ${settings.queueLimit} reached.`,
            code: 'QUEUE_LIMIT_REACHED',
          });
        }
      }

      const allJobs = repository.getJobs().items;
      const jobId = `JOB-00000${allJobs.length + 1}`;

      const newJob: Job = {
        jobId,
        shopName,
        email,
        passwordReference: passwordReference || `sec://vault/passwords/${shopName.toLowerCase().replace(/\s+/g, '-')}`,
        proxyReference: proxyReference || 'proxy://us-residential.lum-pool.net:22225:node-auto',
        status: 'QUEUED',
        subStatus: 'WAITING_FOR_WORKER',
        priority: priority || settings.defaultPriority,
        runMode: runMode || 'AUTO',
        autoStart: autoStart !== undefined ? autoStart : settings.autoStartJobs,
        operatorId: req.user?.operatorId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        retryCount: 0,
        maxRetries: settings.defaultMaxRetries,
        currentAttemptNo: 1,
        tags: Array.isArray(tags) ? tags : ['manual-entry'],
        notes: notes || 'Created via Operations Dashboard',
      };

      repository.saveJob(newJob);

      repository.addAuditLog({
        actor: req.user?.name || 'OPERATOR',
        actorRole: req.user?.role || 'OPERATOR',
        action: 'JOB_CREATED',
        jobId: newJob.jobId,
        newState: 'QUEUED',
        result: 'SUCCESS',
        metadata: { shopName, priority: newJob.priority },
      });

      logger.info('JobCreation', `Job ${newJob.jobId} created for shop ${newJob.shopName}`);
      res.status(201).json(sanitizeJob(newJob));
    } catch (err) {
      next(err);
    }
  }
);

apiRouter.get('/jobs/:jobId', (req: Request, res: Response, next: NextFunction) => {
  try {
    const job = repository.getJobById(req.params.jobId);
    if (!job) {
      return res.status(404).json({ error: 'Job not found', code: 'JOB_NOT_FOUND' });
    }
    const session = job.currentSessionId ? repository.getSessionById(job.currentSessionId) : undefined;
    const humanTasks = repository.getHumanTasksByJobId(job.jobId);
    const attempts = repository.getApplicationAttempts(job.jobId);
    const auditLogs = repository.getAuditLogs({ jobId: job.jobId });

    res.json({
      job: sanitizeJob(job),
      session: session ? sanitizeSession(session) : undefined,
      humanTasks: humanTasks.map(sanitizeHumanTask),
      attempts,
      auditLogs,
    });
  } catch (err) {
    next(err);
  }
});

apiRouter.patch('/jobs/:jobId', requireRole('ADMIN', 'SUPERVISOR', 'OPERATOR'), (req: Request, res: Response, next: NextFunction) => {
  try {
    const job = repository.getJobById(req.params.jobId);
    if (!job) {
      return res.status(404).json({ error: 'Job not found', code: 'JOB_NOT_FOUND' });
    }

    const { priority, operatorId, notes, tags } = req.body;
    if (priority) job.priority = priority;
    if (operatorId !== undefined) job.operatorId = operatorId;
    if (notes !== undefined) job.notes = notes;
    if (tags !== undefined) job.tags = tags;

    repository.saveJob(job);
    res.json(sanitizeJob(job));
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/jobs/:jobId/pause', requireRole('ADMIN', 'SUPERVISOR', 'OPERATOR'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await lockManager.withLock(`job:${req.params.jobId}`, req.user?.name || 'OPERATOR', async () => {
      return workflowEngine.transitionJob({
        jobId: req.params.jobId,
        newStatus: 'PAUSED',
        actor: req.user?.name || 'OPERATOR',
        actorRole: req.user?.role,
        reason: req.body.reason || 'Paused by operator via dashboard',
      });
    });
    res.json(sanitizeJob(result));
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/jobs/:jobId/resume', requireRole('ADMIN', 'SUPERVISOR', 'OPERATOR'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await lockManager.withLock(`job:${req.params.jobId}`, req.user?.name || 'OPERATOR', async () => {
      const job = repository.getJobById(req.params.jobId);
      if (!job) {
        throw new Error('Job not found');
      }
      const targetStatus = job.currentSessionId ? 'BROWSER_READY' : 'QUEUED';
      return workflowEngine.transitionJob({
        jobId: job.jobId,
        newStatus: targetStatus,
        actor: req.user?.name || 'OPERATOR',
        actorRole: req.user?.role,
        reason: 'Resumed by operator',
      });
    });
    res.json(sanitizeJob(result));
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/jobs/:jobId/retry', requireRole('ADMIN', 'SUPERVISOR', 'OPERATOR'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await lockManager.withLock(`job:${req.params.jobId}`, req.user?.name || 'OPERATOR', async () => {
      const job = repository.getJobById(req.params.jobId);
      if (!job) {
        throw new Error('Job not found');
      }
      return retryEngine.scheduleTechnicalRetry({
        jobId: job.jobId,
        errorCode: job.lastErrorCode || 'ERR_PROXY_TIMEOUT',
        errorMessage: job.lastErrorMessage || 'Manual retry triggered by operator',
      });
    });
    res.json(result);
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/jobs/:jobId/manual-review', requireRole('ADMIN', 'SUPERVISOR', 'OPERATOR'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await lockManager.withLock(`job:${req.params.jobId}`, req.user?.name || 'OPERATOR', async () => {
      return workflowEngine.transitionJob({
        jobId: req.params.jobId,
        newStatus: 'MANUAL_REVIEW',
        actor: req.user?.name || 'OPERATOR',
        actorRole: req.user?.role,
        reason: req.body.reason || 'Escalated to supervisor manual review',
      });
    });
    res.json(sanitizeJob(result));
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/jobs/:jobId/submit', requireRole('ADMIN', 'SUPERVISOR', 'OPERATOR'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await lockManager.withLock(`job:${req.params.jobId}`, req.user?.name || 'OPERATOR', async () => {
      return workflowEngine.submitApplication(req.params.jobId, req.user?.name || 'OPERATOR');
    });
    res.json(sanitizeJob(result));
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/jobs/:jobId/reapply', requireRole('ADMIN', 'SUPERVISOR'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await lockManager.withLock(`job:${req.params.jobId}`, req.user?.name || 'SUPERVISOR', async () => {
      return workflowEngine.createReapplicationAttempt(req.params.jobId, req.user?.name || 'SUPERVISOR');
    });
    res.json(sanitizeJob(result));
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/jobs/:jobId/reject', requireRole('ADMIN', 'SUPERVISOR'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await lockManager.withLock(`job:${req.params.jobId}`, req.user?.name || 'SUPERVISOR', async () => {
      return workflowEngine.recordRejection({
        jobId: req.params.jobId,
        rejectionReason: req.body.reason || 'Application rejected by platform review',
        actor: req.user?.name || 'SUPERVISOR',
      });
    });
    res.json(sanitizeJob(result));
  } catch (err) {
    next(err);
  }
});

// ==========================================
// 3. SESSIONS (SANITIZED & CONTROLLED)
// ==========================================
apiRouter.get('/sessions', (req: Request, res: Response, next: NextFunction) => {
  try {
    const { status, operatorId } = req.query;
    const list = repository.getSessions({
      status: status as string,
      operatorId: operatorId as string,
    });
    res.json(list.map(sanitizeSession));
  } catch (err) {
    next(err);
  }
});

apiRouter.get('/sessions/:sessionId', (req: Request, res: Response, next: NextFunction) => {
  try {
    const session = repository.getSessionById(req.params.sessionId);
    if (!session) {
      return res.status(404).json({ error: 'Session not found', code: 'SESSION_NOT_FOUND' });
    }
    res.json(sanitizeSession(session));
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/sessions/:sessionId/stop', requireRole('ADMIN', 'SUPERVISOR', 'OPERATOR'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const success = await goLoginService.stopCloudBrowser(req.params.sessionId);
    res.json({ success });
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/sessions/:sessionId/heartbeat', (req: Request, res: Response, next: NextFunction) => {
  try {
    const session = repository.getSessionById(req.params.sessionId);
    if (!session) {
      return res.status(404).json({ error: 'Session not found', code: 'SESSION_NOT_FOUND' });
    }
    session.lastHeartbeat = new Date().toISOString();
    repository.saveSession(session);
    res.json({ success: true, lastHeartbeat: session.lastHeartbeat });
  } catch (err) {
    next(err);
  }
});

// ==========================================
// 4. HUMAN TASKS (ZERO-BYPASS & SANITIZED)
// ==========================================
apiRouter.get('/human-tasks', (req: Request, res: Response, next: NextFunction) => {
  try {
    const { status, operatorId, priority } = req.query;
    const list = repository.getHumanTasks({
      status: status as string,
      operatorId: operatorId as string,
      priority: priority as string,
    });
    res.json(list.map(sanitizeHumanTask));
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/human-tasks/:taskId/assign', requireRole('ADMIN', 'SUPERVISOR'), (req: Request, res: Response, next: NextFunction) => {
  try {
    const task = repository.getHumanTaskById(req.params.taskId);
    if (!task) {
      return res.status(404).json({ error: 'Task not found', code: 'TASK_NOT_FOUND' });
    }
    task.assignedOperatorId = req.body.operatorId;
    task.status = 'ASSIGNED';
    repository.saveHumanTask(task);
    res.json(sanitizeHumanTask(task));
  } catch (err) {
    next(err);
  }
});

apiRouter.post(
  '/human-tasks/:taskId/complete',
  requireRole('ADMIN', 'SUPERVISOR', 'OPERATOR'),
  validateBody(CompleteHumanTaskSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await lockManager.withLock(`task:${req.params.taskId}`, req.user?.name || 'OPERATOR', async () => {
        return workflowEngine.completeHumanTask({
          taskId: req.params.taskId,
          completedBy: req.user?.name || 'OPERATOR',
          role: req.user?.role,
          notes: req.body.notes,
          payload: req.body.resolutionPayload,
        });
      });
      res.json({
        task: sanitizeHumanTask(result.task),
        job: sanitizeJob(result.job),
      });
    } catch (err) {
      next(err);
    }
  }
);

apiRouter.post('/human-tasks/:taskId/remind', requireRole('ADMIN', 'SUPERVISOR'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const task = repository.getHumanTaskById(req.params.taskId);
    if (!task) {
      return res.status(404).json({ error: 'Task not found', code: 'TASK_NOT_FOUND' });
    }
    task.reminderCount += 1;
    task.lastReminderSentAt = new Date().toISOString();
    repository.saveHumanTask(task);

    const notif = await telegramNotificationService.sendTaskReminder(task, `T+${task.reminderCount * 15}`);
    res.json({ success: true, notification: notif });
  } catch (err) {
    next(err);
  }
});

// ==========================================
// 5. APPLICATION ATTEMPTS HISTORY
// ==========================================
apiRouter.get('/applications/:jobId/attempts', (req: Request, res: Response, next: NextFunction) => {
  try {
    const attempts = repository.getApplicationAttempts(req.params.jobId);
    res.json(attempts);
  } catch (err) {
    next(err);
  }
});

apiRouter.get('/applications/attempts', (req: Request, res: Response, next: NextFunction) => {
  try {
    const attempts = repository.getApplicationAttempts();
    res.json(attempts);
  } catch (err) {
    next(err);
  }
});

// ==========================================
// 6. SYSTEM SETTINGS
// ==========================================
apiRouter.get('/settings', (req: Request, res: Response, next: NextFunction) => {
  try {
    res.json(repository.getSettings());
  } catch (err) {
    next(err);
  }
});

apiRouter.patch(
  '/settings',
  mutationRateLimiter,
  requireRole('ADMIN'),
  validateBody(UpdateSettingsSchema),
  (req: Request, res: Response, next: NextFunction) => {
    try {
      const updates = req.body as Partial<SystemSettings>;
      const updated = repository.updateSettings(updates, req.user?.name || 'ADMIN');
      repository.addAuditLog({
        actor: req.user?.name || 'ADMIN',
        actorRole: 'ADMIN',
        action: 'ADMIN_CHANGED_SETTING',
        result: 'SUCCESS',
        metadata: updates,
      });
      res.json(updated);
    } catch (err) {
      next(err);
    }
  }
);

// ==========================================
// 7. RETRY POLICIES
// ==========================================
apiRouter.get('/retry-policies', (req: Request, res: Response, next: NextFunction) => {
  try {
    res.json(repository.getRetryPolicies());
  } catch (err) {
    next(err);
  }
});

apiRouter.patch(
  '/retry-policies/:policyId',
  requireRole('ADMIN'),
  validateBody(UpdateRetryPolicySchema),
  (req: Request, res: Response, next: NextFunction) => {
    try {
      const policy = repository.getRetryPolicies().find((p) => p.policyId === req.params.policyId);
      if (!policy) {
        return res.status(404).json({ error: 'Retry policy not found', code: 'POLICY_NOT_FOUND' });
      }
      Object.assign(policy, req.body);
      repository.saveRetryPolicy(policy);
      res.json(policy);
    } catch (err) {
      next(err);
    }
  }
);

// ==========================================
// 8. OPERATORS
// ==========================================
apiRouter.get('/operators', (req: Request, res: Response, next: NextFunction) => {
  try {
    res.json(repository.getOperators());
  } catch (err) {
    next(err);
  }
});

apiRouter.post(
  '/operators',
  requireRole('ADMIN'),
  validateBody(CreateOperatorSchema),
  (req: Request, res: Response, next: NextFunction) => {
    try {
      const { name, email, role, telegramChatId, maxConcurrentHumanTasks } = req.body;
      const operators = repository.getOperators();
      const operatorId = `OP-00${operators.length + 1}`;

      const operator = {
        operatorId,
        name,
        email,
        role: role || 'OPERATOR',
        telegramChatId,
        active: true,
        maxConcurrentHumanTasks: maxConcurrentHumanTasks || 4,
        currentTasksCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      repository.saveOperator(operator);
      res.status(201).json(operator);
    } catch (err) {
      next(err);
    }
  }
);

// ==========================================
// 9. GOOGLE SHEETS SYNC
// ==========================================
apiRouter.post('/sheets/sync', requireRole('ADMIN', 'SUPERVISOR'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await googleSheetsService.syncAllSheets();
    res.json(result);
  } catch (err) {
    next(err);
  }
});

apiRouter.get('/sheets/sync/status', (req: Request, res: Response, next: NextFunction) => {
  try {
    res.json(repository.getSheetSyncLogs());
  } catch (err) {
    next(err);
  }
});

apiRouter.get('/sheets/export/csv', (req: Request, res: Response, next: NextFunction) => {
  try {
    const csv = googleSheetsService.exportMasterQueue();
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="master_queue_export.csv"');
    res.send(csv);
  } catch (err) {
    next(err);
  }
});

// ==========================================
// 10. NOTIFICATIONS & TELEGRAM
// ==========================================
apiRouter.get('/notifications', (req: Request, res: Response, next: NextFunction) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 100;
    res.json(repository.getNotifications(limit));
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/notifications/test', requireRole('ADMIN', 'SUPERVISOR'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const notif = await telegramNotificationService.sendNotification({
      type: 'INFO',
      title: 'Manual Test Notification',
      message: req.body.message || 'Test broadcast from Workflow Operations Platform.',
    });
    res.json(notif);
  } catch (err) {
    next(err);
  }
});

// ==========================================
// 11. OUTLOOK / MICROSOFT GRAPH HEALTH
// ==========================================
apiRouter.get('/integrations/outlook/status', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const status = await microsoftGraphService.getMailboxStatus();
    res.json(status);
  } catch (err) {
    next(err);
  }
});

// ==========================================
// 12. AUDIT LOGS (WITH FILTERING & PAGINATION)
// ==========================================
apiRouter.get('/audit-logs', (req: Request, res: Response, next: NextFunction) => {
  try {
    const { jobId, actor, limit } = req.query;
    const logs = repository.getAuditLogs({
      jobId: jobId as string,
      actor: actor as string,
      limit: limit ? parseInt(limit as string, 10) : 100,
    });
    res.json(logs);
  } catch (err) {
    next(err);
  }
});

// ==========================================
// 13. CLOUD SCHEDULER ENDPOINTS
// ==========================================
apiRouter.post('/scheduler/process-queue', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await workflowEngine.processQueue();
    res.json({
      task: 'PROCESS_QUEUE',
      timestamp: new Date().toISOString(),
      ...result,
    });
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/scheduler/process-human-tasks', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const openTasks = repository.getHumanTasks({ status: 'OPEN' });
    let remindersDispatched = 0;
    for (const task of openTasks) {
      task.reminderCount += 1;
      task.lastReminderSentAt = new Date().toISOString();
      repository.saveHumanTask(task);
      await telegramNotificationService.sendTaskReminder(task, `T+${task.reminderCount * 15}`);
      remindersDispatched++;
    }
    res.json({
      task: 'PROCESS_HUMAN_TASKS',
      openTasksChecked: openTasks.length,
      remindersDispatched,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/scheduler/check-reviews', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const reviewJobs = repository.getJobs({ status: 'WAITING_FOR_REVIEW' }).items;
    res.json({
      task: 'CHECK_REVIEWS',
      reviewJobsChecked: reviewJobs.length,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    next(err);
  }
});

// ==========================================
// 14. REPORTS
// ==========================================
apiRouter.get('/reports', (req: Request, res: Response, next: NextFunction) => {
  try {
    const jobs = repository.getJobs().items;
    const attempts = repository.getApplicationAttempts();
    const humanTasks = repository.getHumanTasks();

    const statusDistribution: Record<string, number> = {};
    jobs.forEach((j) => {
      statusDistribution[j.status] = (statusDistribution[j.status] || 0) + 1;
    });

    const outcomeDistribution = {
      APPROVED: attempts.filter((a) => a.finalStatus === 'APPROVED').length,
      REJECTED: attempts.filter((a) => a.finalStatus === 'REJECTED').length,
      PENDING: attempts.filter((a) => a.finalStatus === 'PENDING').length,
    };

    res.json({
      totalJobs: jobs.length,
      totalAttempts: attempts.length,
      statusDistribution,
      outcomeDistribution,
      avgCompletionMinutes: 24.5,
      avgHumanTaskMinutes: 11.2,
      activeSessionsCount: repository.getSessions().filter((s) => s.status === 'RUNNING' || s.status === 'PAUSED').length,
    });
  } catch (err) {
    next(err);
  }
});

// ==========================================
// 15. ADMIN UTILITIES
// ==========================================
apiRouter.post('/admin/reset-demo-data', requireRole('ADMIN'), (req: Request, res: Response, next: NextFunction) => {
  try {
    repository.resetDemoData();
    res.json({ success: true, message: 'Platform demo data successfully reset.' });
  } catch (err) {
    next(err);
  }
});
