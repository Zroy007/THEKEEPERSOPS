import { repository } from '../db/repository.js';
import {
  Job,
  JobStatus,
  HumanTask,
  HumanTaskType,
  ApplicationAttempt,
  UserRole,
} from '../types.js';
import { goLoginService } from './gologin.service.js';
import { telegramNotificationService } from './telegram.service.js';
import { lockManager } from '../utils/concurrencyLock.js';
import { logger } from '../utils/logger.js';

// Deterministic state transition mapping
export const VALID_TRANSITIONS: Record<JobStatus, JobStatus[]> = {
  NEW: ['QUEUED', 'CANCELLED'],
  QUEUED: ['PREPARING', 'PAUSED', 'CANCELLED'],
  PREPARING: ['PROFILE_CREATED', 'ERROR', 'PAUSED'],
  PROFILE_CREATED: ['PROXY_CHECKING', 'PROXY_READY', 'ERROR', 'PAUSED'],
  PROXY_CHECKING: ['PROXY_READY', 'ERROR', 'RETRY_PENDING', 'MANUAL_REVIEW'],
  PROXY_READY: ['BROWSER_STARTING', 'ERROR', 'PAUSED'],
  BROWSER_STARTING: ['BROWSER_READY', 'ERROR', 'RETRY_PENDING', 'MANUAL_REVIEW'],
  BROWSER_READY: ['SIGNUP_STARTED', 'PAUSED', 'ERROR'],
  SIGNUP_STARTED: ['WAITING_FOR_EMAIL_OTP', 'PASSWORD_STAGE', 'ERROR', 'PAUSED'],
  WAITING_FOR_EMAIL_OTP: ['HUMAN_ACTION_COMPLETED', 'ERROR', 'PAUSED', 'MANUAL_REVIEW'],
  PASSWORD_STAGE: ['REGISTRATION_CONTINUING', 'ERROR', 'PAUSED'],
  REGISTRATION_CONTINUING: [
    'HUMAN_IDENTITY_VERIFICATION',
    'HUMAN_SELFIE_REQUIRED',
    'HUMAN_BIOMETRIC_REQUIRED',
    'SHOP_INFORMATION',
    'PHONE_VERIFICATION',
    'READY_FOR_SUBMISSION',
    'ERROR',
    'PAUSED',
  ],
  HUMAN_IDENTITY_VERIFICATION: ['HUMAN_ACTION_COMPLETED', 'MANUAL_REVIEW', 'ERROR', 'PAUSED'],
  HUMAN_SELFIE_REQUIRED: ['HUMAN_ACTION_COMPLETED', 'MANUAL_REVIEW', 'ERROR', 'PAUSED'],
  HUMAN_BIOMETRIC_REQUIRED: ['HUMAN_ACTION_COMPLETED', 'MANUAL_REVIEW', 'ERROR', 'PAUSED'],
  HUMAN_ACTION_COMPLETED: ['SHOP_INFORMATION', 'PHONE_VERIFICATION', 'READY_FOR_SUBMISSION', 'ERROR'],
  SHOP_INFORMATION: ['PHONE_VERIFICATION', 'READY_FOR_SUBMISSION', 'ERROR', 'PAUSED'],
  PHONE_VERIFICATION: ['HUMAN_ACTION_COMPLETED', 'READY_FOR_SUBMISSION', 'MANUAL_REVIEW', 'ERROR', 'PAUSED'],
  READY_FOR_SUBMISSION: ['SUBMITTED', 'MANUAL_REVIEW', 'ERROR', 'PAUSED'],
  SUBMITTED: ['WAITING_FOR_REVIEW', 'MANUAL_REVIEW', 'ERROR'],
  WAITING_FOR_REVIEW: ['APPROVED', 'REJECTED', 'MANUAL_REVIEW', 'ERROR'],
  APPROVED: ['COMPLETED'],
  REJECTED: ['MANUAL_REVIEW', 'QUEUED'], // If reapplication allowed
  CANCELLED: [],
  PAUSED: ['QUEUED', 'PREPARING', 'BROWSER_READY', 'SIGNUP_STARTED', 'WAITING_FOR_EMAIL_OTP', 'HUMAN_IDENTITY_VERIFICATION', 'SUBMITTED', 'CANCELLED'],
  ERROR: ['RETRY_PENDING', 'MANUAL_REVIEW', 'CANCELLED'],
  RETRY_PENDING: ['QUEUED', 'PREPARING', 'PROXY_CHECKING', 'BROWSER_STARTING'],
  MANUAL_REVIEW: ['QUEUED', 'READY_FOR_SUBMISSION', 'REJECTED', 'CANCELLED'],
  COMPLETED: [],
};

export class WorkflowEngine {
  /**
   * Validate and transition job state deterministically
   */
  public async transitionJob(params: {
    jobId: string;
    newStatus: JobStatus;
    actor: string;
    actorRole?: UserRole;
    reason?: string;
    metadata?: Record<string, any>;
  }): Promise<Job> {
    const job = repository.getJobById(params.jobId);
    if (!job) {
      throw new Error(`Job not found: ${params.jobId}`);
    }

    const currentStatus = job.status;
    const allowed = VALID_TRANSITIONS[currentStatus] || [];

    // Allow self-transition or transitions from PAUSED/ERROR with supervisor permission
    const isSpecialOverride =
      params.actorRole === 'ADMIN' ||
      params.actorRole === 'SUPERVISOR' ||
      params.newStatus === 'PAUSED' ||
      params.newStatus === 'CANCELLED' ||
      params.newStatus === 'ERROR';

    if (!allowed.includes(params.newStatus) && !isSpecialOverride && currentStatus !== params.newStatus) {
      throw new Error(
        `Invalid state transition: Cannot move Job ${job.jobId} from ${currentStatus} to ${params.newStatus}. Allowed: [${allowed.join(', ')}]`
      );
    }

    job.status = params.newStatus;
    job.updatedAt = new Date().toISOString();

    // Map sub-status based on new status
    switch (params.newStatus) {
      case 'QUEUED':
        job.subStatus = 'WAITING_FOR_WORKER';
        break;
      case 'WAITING_FOR_EMAIL_OTP':
      case 'HUMAN_IDENTITY_VERIFICATION':
      case 'HUMAN_SELFIE_REQUIRED':
      case 'HUMAN_BIOMETRIC_REQUIRED':
      case 'PHONE_VERIFICATION':
        job.subStatus = 'AWAITING_HUMAN';
        break;
      case 'WAITING_FOR_REVIEW':
        job.subStatus = 'REVIEW_POLLING';
        // Set next check time (e.g. +30 mins)
        job.nextCheckAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
        break;
      case 'APPROVED':
      case 'COMPLETED':
        job.subStatus = 'SUCCESS';
        job.completedAt = new Date().toISOString();
        break;
      case 'ERROR':
        job.subStatus = 'FAILED_TRANSIENT';
        break;
      case 'MANUAL_REVIEW':
        job.subStatus = 'MANUAL_ATTENTION';
        break;
      default:
        job.subStatus = 'IN_PROGRESS';
    }

    repository.saveJob(job);

    // Record Append-Only Audit Log
    repository.addAuditLog({
      actor: params.actor,
      actorRole: params.actorRole || 'ADMIN',
      action: 'STATE_TRANSITION',
      jobId: job.jobId,
      sessionId: job.currentSessionId,
      previousState: currentStatus,
      newState: params.newStatus,
      result: 'SUCCESS',
      reason: params.reason,
      metadata: params.metadata,
    });

    // Checkpoint Handler: Auto-generate Human Task if entering human checkpoint
    await this.handleHumanCheckpoint(job, params.newStatus);

    return job;
  }

  /**
   * Human Checkpoint Principle:
   * Pause automated loop, keep browser session alive, create HUMAN_TASK, alert operator.
   */
  private async handleHumanCheckpoint(job: Job, status: JobStatus) {
    let taskType: HumanTaskType | null = null;
    let title = '';
    let description = '';

    if (status === 'WAITING_FOR_EMAIL_OTP') {
      taskType = 'EMAIL_OTP';
      title = `Email OTP Verification: ${job.shopName}`;
      description = `1. Check authorized Outlook mailbox for ${job.email}.\n2. Retrieve 6-digit confirmation code.\n3. Enter manually into active browser session.\n4. Confirm completion here.`;
      job.humanAction = 'Awaiting manual entry of Email OTP from Outlook';
    } else if (status === 'HUMAN_IDENTITY_VERIFICATION') {
      taskType = 'IDENTITY_VERIFICATION';
      title = `Identity Verification Checkpoint: ${job.shopName}`;
      description = `Operator must perform required government ID document verification in active session.`;
      job.humanAction = 'Perform manual ID document verification in session';
    } else if (status === 'HUMAN_SELFIE_REQUIRED') {
      taskType = 'SELFIE';
      title = `Selfie Checkpoint: ${job.shopName}`;
      description = `Operator must complete selfie check in session.`;
      job.humanAction = 'Complete selfie verification in session';
    } else if (status === 'HUMAN_BIOMETRIC_REQUIRED') {
      taskType = 'BIOMETRIC';
      title = `Biometric Checkpoint: ${job.shopName}`;
      description = `Operator must confirm biometric authentication.`;
      job.humanAction = 'Complete biometric confirmation';
    } else if (status === 'PHONE_VERIFICATION') {
      taskType = 'PHONE_VERIFICATION';
      title = `Phone Verification Checkpoint: ${job.shopName}`;
      description = `Operator must verify SMS / phone code in session.`;
      job.humanAction = 'Complete manual SMS phone verification';
    }

    if (taskType) {
      const settings = repository.getSettings();
      const existingTask = repository.getHumanTasksByJobId(job.jobId).find(
        (t) => t.status === 'OPEN' || t.status === 'IN_PROGRESS' || t.status === 'ASSIGNED'
      );

      if (!existingTask) {
        const taskId = `TASK-${Date.now().toString().slice(-4)}${Math.floor(Math.random() * 10)}`;
        const dueAt = new Date(Date.now() + settings.otpTimeoutMinutes * 60 * 1000).toISOString();

        const task: HumanTask = {
          humanTaskId: taskId,
          jobId: job.jobId,
          sessionId: job.currentSessionId,
          taskType,
          title,
          description,
          priority: job.priority,
          status: 'OPEN',
          assignedOperatorId: job.operatorId,
          createdAt: new Date().toISOString(),
          dueAt,
          reminderCount: 0,
        };

        repository.saveHumanTask(task);
        repository.saveJob(job);

        // Notify Operator via Telegram
        await telegramNotificationService.sendHumanTaskAlert(task, job);
      }
    }
  }

  /**
   * Complete a Human Task and advance workflow
   */
  public async completeHumanTask(params: {
    taskId: string;
    completedBy: string;
    role?: UserRole;
    notes?: string;
    payload?: Record<string, any>;
  }): Promise<{ task: HumanTask; job: Job }> {
    const task = repository.getHumanTaskById(params.taskId);
    if (!task) throw new Error(`Task not found: ${params.taskId}`);

    const job = repository.getJobById(task.jobId);
    if (!job) throw new Error(`Associated Job not found: ${task.jobId}`);

    task.status = 'COMPLETED';
    task.completedAt = new Date().toISOString();
    task.completedBy = params.completedBy;
    task.notes = params.notes;
    task.resolutionPayload = params.payload;
    repository.saveHumanTask(task);

    job.humanAction = undefined;

    // Transition job to HUMAN_ACTION_COMPLETED then resume
    await this.transitionJob({
      jobId: job.jobId,
      newStatus: 'HUMAN_ACTION_COMPLETED',
      actor: params.completedBy,
      actorRole: params.role || 'OPERATOR',
      reason: `Operator ${params.completedBy} completed human checkpoint [${task.taskType}].`,
    });

    // Advance to next step (e.g. SHOP_INFORMATION or READY_FOR_SUBMISSION)
    await this.transitionJob({
      jobId: job.jobId,
      newStatus: 'READY_FOR_SUBMISSION',
      actor: 'WORKFLOW_ENGINE',
      reason: 'Automated post-checkpoint continuation.',
    });

    return { task, job };
  }

  /**
   * Process Background Queue:
   * Dynamic concurrency checking!
   * availableCapacity = configuredCapacity - activeSessions
   */
  public async processQueue(): Promise<{ startedJobs: number; capacityRemaining: number }> {
    const settings = repository.getSettings();
    if (settings.maintenanceMode) {
      return { startedJobs: 0, capacityRemaining: 0 };
    }

    const sessions = repository.getSessions();
    const activeSessions = sessions.filter((s) => s.status === 'RUNNING' || s.status === 'STARTING').length;

    const capacityLimit = settings.concurrencyLimit;
    const availableCapacity = capacityLimit !== null ? Math.max(0, capacityLimit - activeSessions) : 999;

    if (availableCapacity <= 0) {
      return { startedJobs: 0, capacityRemaining: 0 };
    }

    const queuedJobs = repository
      .getJobs({ status: 'QUEUED' })
      .items.filter((j) => j.autoStart)
      .slice(0, availableCapacity);

    let startedJobs = 0;
    for (const job of queuedJobs) {
      try {
        const acquired = await lockManager.acquireLock(`job:${job.jobId}`, 'queue_worker', 45000);
        if (!acquired) {
          logger.warn('QueueWorker', `Job ${job.jobId} is locked by another worker. Skipping.`);
          continue;
        }

        try {
          await this.startJobExecution(job);
          startedJobs++;
        } finally {
          await lockManager.releaseLock(`job:${job.jobId}`, 'queue_worker');
        }
      } catch (err: any) {
        logger.error('QueueWorker', `Error starting queued job ${job.jobId}: ${err.message}`);
      }
    }

    const updatedRemaining = capacityLimit !== null ? Math.max(0, capacityLimit - (activeSessions + startedJobs)) : 999;
    return { startedJobs, capacityRemaining: updatedRemaining };
  }

  /**
   * Checks for duplicate active jobs with same shopName or email
   */
  public checkDuplicateJob(shopName: string, email: string): { isDuplicate: boolean; existingJob?: Job } {
    const activeJobs = repository.getJobs().items.filter(
      (j) => !['COMPLETED', 'CANCELLED', 'REJECTED'].includes(j.status)
    );
    const existing = activeJobs.find(
      (j) =>
        j.shopName.trim().toLowerCase() === shopName.trim().toLowerCase() ||
        j.email.trim().toLowerCase() === email.trim().toLowerCase()
    );
    return {
      isDuplicate: !!existing,
      existingJob: existing,
    };
  }

  /**
   * Step a job through browser startup and preparation with exclusive lock
   */
  public async startJobExecution(job: Job): Promise<Job> {
    return lockManager.withLock(`job_execution:${job.jobId}`, 'job_executor', async () => {
      // 1. Transition to PREPARING
      await this.transitionJob({
        jobId: job.jobId,
        newStatus: 'PREPARING',
        actor: 'QUEUE_MANAGER',
        reason: 'Acquired capacity slot in queue worker.',
      });

      // 2. GoLogin Profile creation if not existing
      if (!job.gologinProfileId) {
        const { profileId, profileName } = await goLoginService.createProfile(job.jobId, job.shopName, job.proxyReference);
        job.gologinProfileId = profileId;
        job.gologinProfileName = profileName;
        repository.saveJob(job);
      }

      await this.transitionJob({
        jobId: job.jobId,
        newStatus: 'PROFILE_CREATED',
        actor: 'WORKFLOW_ENGINE',
      });

      // 3. Proxy Check
      await this.transitionJob({
        jobId: job.jobId,
        newStatus: 'PROXY_CHECKING',
        actor: 'WORKFLOW_ENGINE',
        reason: 'Validating residential proxy tunnel.',
      });

      await this.transitionJob({
        jobId: job.jobId,
        newStatus: 'PROXY_READY',
        actor: 'WORKFLOW_ENGINE',
        reason: 'Residential proxy tunnel validated.',
      });

      // 4. Start Cloud Browser
      await this.transitionJob({
        jobId: job.jobId,
        newStatus: 'BROWSER_STARTING',
        actor: 'WORKFLOW_ENGINE',
      });

      const session = await goLoginService.startCloudBrowser(job.gologinProfileId!, job);
      job.currentSessionId = session.sessionId;
      job.startedAt = new Date().toISOString();
      repository.saveJob(job);

      await this.transitionJob({
        jobId: job.jobId,
        newStatus: 'BROWSER_READY',
        actor: 'WORKFLOW_ENGINE',
        reason: `Cloud browser session ${session.sessionId} ready.`,
      });

      // 5. Signup started
      await this.transitionJob({
        jobId: job.jobId,
        newStatus: 'SIGNUP_STARTED',
        actor: 'WORKFLOW_ENGINE',
        reason: 'Navigated to merchant signup portal.',
      });

      return job;
    });
  }

  /**
   * Submit application & track attempt history without overwriting
   */
  public async submitApplication(jobId: string, actor: string): Promise<Job> {
    const job = repository.getJobById(jobId);
    if (!job) throw new Error(`Job not found: ${jobId}`);

    const attemptNo = job.currentAttemptNo || 1;
    const attemptId = `ATT-${job.jobId.replace('JOB-', '')}-${attemptNo}`;

    // Create immutable attempt record
    const attempt: ApplicationAttempt = {
      attemptId,
      attemptNo,
      jobId: job.jobId,
      shopName: job.shopName,
      email: job.email,
      gologinProfileId: job.gologinProfileId,
      submittedAt: new Date().toISOString(),
      reviewStartedAt: new Date().toISOString(),
      finalStatus: 'PENDING',
      nextAttemptAllowed: true,
      operatorId: job.operatorId,
      createdAt: new Date().toISOString(),
      notes: `Submission attempt #${attemptNo} logged.`,
    };
    repository.saveApplicationAttempt(attempt);

    job.submittedAt = new Date().toISOString();
    repository.saveJob(job);

    await this.transitionJob({
      jobId: job.jobId,
      newStatus: 'SUBMITTED',
      actor,
      reason: `Application submitted for attempt #${attemptNo}.`,
    });

    await this.transitionJob({
      jobId: job.jobId,
      newStatus: 'WAITING_FOR_REVIEW',
      actor: 'WORKFLOW_ENGINE',
      reason: 'Moved to review monitor queue.',
    });

    return job;
  }

  /**
   * Record Application Rejection and prepare reapplication attempt
   */
  public async recordRejection(params: {
    jobId: string;
    rejectionReason: string;
    actor: string;
  }): Promise<Job> {
    const job = repository.getJobById(params.jobId);
    if (!job) throw new Error(`Job not found: ${params.jobId}`);

    const currentAttempts = repository.getApplicationAttempts(job.jobId);
    const latestAttempt = currentAttempts[0];
    if (latestAttempt) {
      latestAttempt.finalStatus = 'REJECTED';
      latestAttempt.rejectionReason = params.rejectionReason;
      latestAttempt.completedAt = new Date().toISOString();
      repository.saveApplicationAttempt(latestAttempt);
    }

    job.lastErrorCode = 'APPLICATION_REJECTED';
    job.lastErrorMessage = params.rejectionReason;
    repository.saveJob(job);

    await this.transitionJob({
      jobId: job.jobId,
      newStatus: 'REJECTED',
      actor: params.actor,
      reason: params.rejectionReason,
    });

    return job;
  }

  /**
   * Create a new legitimate reapplication attempt (e.g. ATTEMPT #2, #3)
   * Does NOT overwrite attempt 1!
   */
  public async createReapplicationAttempt(jobId: string, actor: string): Promise<Job> {
    const job = repository.getJobById(jobId);
    if (!job) throw new Error(`Job not found: ${jobId}`);

    job.currentAttemptNo = (job.currentAttemptNo || 1) + 1;
    job.status = 'QUEUED';
    job.subStatus = 'WAITING_FOR_WORKER';
    job.notes = `New reapplication attempt #${job.currentAttemptNo} requested by ${actor}.`;
    job.updatedAt = new Date().toISOString();
    repository.saveJob(job);

    repository.addAuditLog({
      actor,
      actorRole: 'SUPERVISOR',
      action: 'REAPPLICATION_CREATED',
      jobId: job.jobId,
      previousState: 'REJECTED',
      newState: 'QUEUED',
      result: 'SUCCESS',
      metadata: { attemptNo: job.currentAttemptNo },
    });

    return job;
  }
}

export const workflowEngine = new WorkflowEngine();
