import fs from 'fs';
import path from 'path';
import {
  Job,
  Session,
  HumanTask,
  Operator,
  SystemSettings,
  RetryPolicy,
  ApplicationAttempt,
  AuditLog,
  IntegrationStatusItem,
  Notification,
  SheetSyncLog,
  WorkflowRun,
  UserAccount,
  RoleDefinition,
  SettingVersion,
} from '../types.js';
import {
  initialJobs,
  initialSessions,
  initialHumanTasks,
  initialOperators,
  initialSettings,
  initialRetryPolicies,
  initialApplicationAttempts,
  initialAuditLogs,
  initialIntegrations,
  initialUserAccounts,
} from './seed.js';
import { INITIAL_ROLE_DEFINITIONS, authService } from '../services/auth.service.js';

interface DatabaseSchema {
  jobs: Record<string, Job>;
  sessions: Record<string, Session>;
  humanTasks: Record<string, HumanTask>;
  operators: Record<string, Operator>;
  userAccounts: Record<string, UserAccount>;
  roles: Record<string, RoleDefinition>;
  systemSettings: SystemSettings;
  settingsVersions: SettingVersion[];
  retryPolicies: Record<string, RetryPolicy>;
  applicationAttempts: Record<string, ApplicationAttempt>;
  auditLogs: AuditLog[];
  notifications: Notification[];
  integrationStatus: Record<string, IntegrationStatusItem>;
  sheetSyncLogs: SheetSyncLog[];
  workflowRuns: Record<string, WorkflowRun>;
}

class Repository {
  private data: DatabaseSchema;
  private dbFilePath: string;
  private isWriting = false;

  constructor() {
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      try {
        fs.mkdirSync(dataDir, { recursive: true });
      } catch (err) {
        console.error('Failed to create data directory:', err);
      }
    }
    this.dbFilePath = path.join(dataDir, 'platform_db.json');
    this.data = this.loadDatabase();
  }

  private loadDatabase(): DatabaseSchema {
    let parsed: any = null;
    if (fs.existsSync(this.dbFilePath)) {
      try {
        const raw = fs.readFileSync(this.dbFilePath, 'utf-8');
        parsed = JSON.parse(raw);
      } catch (err) {
        console.error('Error reading persisted database file, re-initializing with seed data:', err);
      }
    }

    // Default Seed Data
    const bootstrapPassword = process.env.BOOTSTRAP_SUPERADMIN_PASSWORD || 'SuperAdmin@Init2026!';
    const { hash: bootstrapHash, salt: bootstrapSalt } = authService.hashPassword(bootstrapPassword);

    const accountsMap: Record<string, UserAccount> = {};
    for (const acc of initialUserAccounts) {
      if (acc.role === 'SUPERADMIN') {
        accountsMap[acc.uid] = {
          ...acc,
          passwordHash: bootstrapHash,
          passwordSalt: bootstrapSalt,
          mustChangePassword: true,
        };
      } else {
        const { hash, salt } = authService.hashPassword('Operator@2026!');
        accountsMap[acc.uid] = {
          ...acc,
          passwordHash: hash,
          passwordSalt: salt,
          mustChangePassword: false,
        };
      }
    }

    const rolesMap: Record<string, RoleDefinition> = Object.fromEntries(
      INITIAL_ROLE_DEFINITIONS.map((r) => [r.roleId, { ...r }])
    );

    if (parsed) {
      if (!parsed.userAccounts || Object.keys(parsed.userAccounts).length === 0) {
        parsed.userAccounts = accountsMap;
      } else {
        // Ensure bootstrap super admin exists
        const hasSuperAdmin = Object.values(parsed.userAccounts).some(
          (u: any) => u.email === 'zakwanrhmn@gmail.com' || u.role === 'SUPERADMIN'
        );
        if (!hasSuperAdmin) {
          parsed.userAccounts['USR-SUPERADMIN-001'] = accountsMap['USR-SUPERADMIN-001'];
        }
      }

      if (!parsed.roles || Object.keys(parsed.roles).length === 0) {
        parsed.roles = rolesMap;
      }
      if (!parsed.settingsVersions) {
        parsed.settingsVersions = [];
      }
      return parsed as DatabaseSchema;
    }

    const seed: DatabaseSchema = {
      jobs: Object.fromEntries(initialJobs.map((j) => [j.jobId, j])),
      sessions: Object.fromEntries(initialSessions.map((s) => [s.sessionId, s])),
      humanTasks: Object.fromEntries(initialHumanTasks.map((t) => [t.humanTaskId, t])),
      operators: Object.fromEntries(initialOperators.map((o) => [o.operatorId, o])),
      userAccounts: accountsMap,
      roles: rolesMap,
      systemSettings: { ...initialSettings },
      settingsVersions: [
        {
          versionId: 'VER-001',
          version: 1,
          settingKey: 'concurrencyLimit',
          oldValue: null,
          newValue: 12,
          changedBy: 'SYSTEM_BOOTSTRAP',
          changedAt: new Date().toISOString(),
          changeType: 'UPDATE',
        },
      ],
      retryPolicies: Object.fromEntries(initialRetryPolicies.map((r) => [r.policyId, r])),
      applicationAttempts: Object.fromEntries(initialApplicationAttempts.map((a) => [a.attemptId, a])),
      auditLogs: [...initialAuditLogs],
      notifications: [],
      integrationStatus: Object.fromEntries(initialIntegrations.map((i) => [i.id, i])),
      sheetSyncLogs: [],
      workflowRuns: {},
    };

    this.saveDatabase(seed);
    return seed;
  }

  private saveDatabase(stateToSave?: DatabaseSchema) {
    if (this.isWriting) return;
    this.isWriting = true;
    try {
      const dataToSave = stateToSave || this.data;
      fs.writeFileSync(this.dbFilePath, JSON.stringify(dataToSave, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to persist database file:', err);
    } finally {
      this.isWriting = false;
    }
  }

  // --- JOBS ---
  public getJobs(filter?: {
    status?: string;
    operatorId?: string;
    search?: string;
    priority?: string;
    limit?: number;
    offset?: number;
  }): { items: Job[]; total: number } {
    let list = Object.values(this.data.jobs);

    if (filter?.status && filter.status !== 'ALL') {
      list = list.filter((j) => j.status === filter.status);
    }
    if (filter?.operatorId && filter.operatorId !== 'ALL') {
      list = list.filter((j) => j.operatorId === filter.operatorId);
    }
    if (filter?.priority && filter.priority !== 'ALL') {
      list = list.filter((j) => j.priority === filter.priority);
    }
    if (filter?.search) {
      const q = filter.search.toLowerCase();
      list = list.filter(
        (j) =>
          j.jobId.toLowerCase().includes(q) ||
          j.shopName.toLowerCase().includes(q) ||
          j.email.toLowerCase().includes(q) ||
          (j.tags && j.tags.some((t) => t.toLowerCase().includes(q)))
      );
    }

    // Sort by updatedAt descending
    list.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

    const total = list.length;
    const offset = filter?.offset || 0;
    const limit = filter?.limit || 50;
    const items = list.slice(offset, offset + limit);

    return { items, total };
  }

  public getJobById(jobId: string): Job | undefined {
    return this.data.jobs[jobId];
  }

  public saveJob(job: Job): Job {
    job.updatedAt = new Date().toISOString();
    this.data.jobs[job.jobId] = job;
    this.saveDatabase();
    return job;
  }

  public deleteJob(jobId: string): boolean {
    if (this.data.jobs[jobId]) {
      delete this.data.jobs[jobId];
      this.saveDatabase();
      return true;
    }
    return false;
  }

  // --- SESSIONS ---
  public getSessions(filter?: { status?: string; operatorId?: string }): Session[] {
    let list = Object.values(this.data.sessions);
    if (filter?.status && filter.status !== 'ALL') {
      list = list.filter((s) => s.status === filter.status);
    }
    if (filter?.operatorId && filter.operatorId !== 'ALL') {
      list = list.filter((s) => s.operatorId === filter.operatorId);
    }
    // Sort active sessions first
    return list.sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime());
  }

  public getSessionById(sessionId: string): Session | undefined {
    return this.data.sessions[sessionId];
  }

  public getSessionByJobId(jobId: string): Session | undefined {
    return Object.values(this.data.sessions).find((s) => s.jobId === jobId);
  }

  public saveSession(session: Session): Session {
    session.lastHeartbeat = new Date().toISOString();
    this.data.sessions[session.sessionId] = session;
    this.saveDatabase();
    return session;
  }

  public deleteSession(sessionId: string): boolean {
    if (this.data.sessions[sessionId]) {
      delete this.data.sessions[sessionId];
      this.saveDatabase();
      return true;
    }
    return false;
  }

  // --- HUMAN TASKS ---
  public getHumanTasks(filter?: { status?: string; operatorId?: string; priority?: string }): HumanTask[] {
    let list = Object.values(this.data.humanTasks);
    if (filter?.status && filter.status !== 'ALL') {
      list = list.filter((t) => t.status === filter.status);
    }
    if (filter?.operatorId && filter.operatorId !== 'ALL') {
      list = list.filter((t) => t.assignedOperatorId === filter.operatorId);
    }
    if (filter?.priority && filter.priority !== 'ALL') {
      list = list.filter((t) => t.priority === filter.priority);
    }
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public getHumanTaskById(taskId: string): HumanTask | undefined {
    return this.data.humanTasks[taskId];
  }

  public getHumanTasksByJobId(jobId: string): HumanTask[] {
    return Object.values(this.data.humanTasks).filter((t) => t.jobId === jobId);
  }

  public saveHumanTask(task: HumanTask): HumanTask {
    this.data.humanTasks[task.humanTaskId] = task;
    this.saveDatabase();
    return task;
  }

  // --- OPERATORS ---
  public getOperators(): Operator[] {
    return Object.values(this.data.operators);
  }

  public getOperatorById(operatorId: string): Operator | undefined {
    return this.data.operators[operatorId];
  }

  public saveOperator(operator: Operator): Operator {
    operator.updatedAt = new Date().toISOString();
    this.data.operators[operator.operatorId] = operator;
    this.saveDatabase();
    return operator;
  }

  // --- USER ACCOUNTS ---
  public getUserAccounts(filter?: {
    search?: string;
    role?: string;
    status?: string;
  }): UserAccount[] {
    let list = Object.values(this.data.userAccounts);
    if (filter?.role && filter.role !== 'ALL') {
      list = list.filter((u) => u.role === filter.role);
    }
    if (filter?.status && filter.status !== 'ALL') {
      list = list.filter((u) => u.status === filter.status);
    }
    if (filter?.search) {
      const q = filter.search.toLowerCase();
      list = list.filter(
        (u) =>
          u.name.toLowerCase().includes(q) ||
          u.email.toLowerCase().includes(q) ||
          u.uid.toLowerCase().includes(q)
      );
    }
    // Return sanitized accounts (no passwordHash or passwordSalt leaked in listing)
    return list.map((u) => {
      const { passwordHash, passwordSalt, ...safe } = u;
      return safe as UserAccount;
    });
  }

  public getUserAccountById(uid: string, includeSecrets = false): UserAccount | undefined {
    const acc = this.data.userAccounts[uid];
    if (!acc) return undefined;
    if (includeSecrets) return acc;
    const { passwordHash, passwordSalt, ...safe } = acc;
    return safe as UserAccount;
  }

  public getUserAccountByEmail(email: string, includeSecrets = false): UserAccount | undefined {
    const lower = email.toLowerCase().trim();
    const acc = Object.values(this.data.userAccounts).find(
      (u) => u.email.toLowerCase().trim() === lower
    );
    if (!acc) return undefined;
    if (includeSecrets) return acc;
    const { passwordHash, passwordSalt, ...safe } = acc;
    return safe as UserAccount;
  }

  public saveUserAccount(user: UserAccount, actor = 'SUPERADMIN'): UserAccount {
    const existing = this.data.userAccounts[user.uid];

    // Safety constraint: Protect the last active SUPERADMIN
    if (existing && existing.role === 'SUPERADMIN') {
      const isDemotingOrDisabling =
        (user.role && user.role !== 'SUPERADMIN') ||
        (user.status && user.status !== 'ACTIVE');

      if (isDemotingOrDisabling) {
        const otherActiveSuperAdmins = Object.values(this.data.userAccounts).filter(
          (u) => u.uid !== user.uid && u.role === 'SUPERADMIN' && u.status === 'ACTIVE'
        );
        if (otherActiveSuperAdmins.length === 0) {
          throw new Error('Cannot demote, disable, or lock the last remaining active Super Admin account.');
        }
      }
    }

    user.updatedAt = new Date().toISOString();
    if (!user.createdAt) user.createdAt = new Date().toISOString();

    // Preserve password hash/salt if not supplied in update
    if (existing) {
      if (!user.passwordHash && existing.passwordHash) {
        user.passwordHash = existing.passwordHash;
      }
      if (!user.passwordSalt && existing.passwordSalt) {
        user.passwordSalt = existing.passwordSalt;
      }
    }

    this.data.userAccounts[user.uid] = user;
    this.saveDatabase();

    this.addAuditLog({
      actor,
      actorRole: 'SUPERADMIN',
      action: existing ? 'ACCOUNT_UPDATED' : 'ACCOUNT_CREATED',
      newState: user.status,
      result: 'SUCCESS',
      metadata: { targetUid: user.uid, targetEmail: user.email, targetRole: user.role },
    });

    const { passwordHash, passwordSalt, ...safe } = user;
    return safe as UserAccount;
  }

  public deleteUserAccount(uid: string, actor = 'SUPERADMIN'): boolean {
    const existing = this.data.userAccounts[uid];
    if (!existing) return false;

    // Safety constraint: Protect the last active SUPERADMIN
    if (existing.role === 'SUPERADMIN') {
      const otherActiveSuperAdmins = Object.values(this.data.userAccounts).filter(
        (u) => u.uid !== uid && u.role === 'SUPERADMIN' && u.status === 'ACTIVE'
      );
      if (otherActiveSuperAdmins.length === 0) {
        throw new Error('Cannot delete the last remaining active Super Admin account.');
      }
    }

    delete this.data.userAccounts[uid];
    this.saveDatabase();

    this.addAuditLog({
      actor,
      actorRole: 'SUPERADMIN',
      action: 'ACCOUNT_DELETED',
      result: 'SUCCESS',
      metadata: { deletedUid: uid, deletedEmail: existing.email },
    });

    return true;
  }

  public unlockUserAccount(uid: string, actor = 'SUPERADMIN'): UserAccount {
    const acc = this.data.userAccounts[uid];
    if (!acc) throw new Error('Account not found');
    acc.status = 'ACTIVE';
    acc.failedLoginAttempts = 0;
    acc.updatedAt = new Date().toISOString();
    this.saveDatabase();

    this.addAuditLog({
      actor,
      actorRole: 'SUPERADMIN',
      action: 'ACCOUNT_UNLOCKED',
      newState: 'ACTIVE',
      result: 'SUCCESS',
      metadata: { targetUid: uid, targetEmail: acc.email },
    });

    const { passwordHash, passwordSalt, ...safe } = acc;
    return safe as UserAccount;
  }

  // --- ROLES ---
  public getRoles(): RoleDefinition[] {
    const roles = Object.values(this.data.roles);
    // Count active users for each role
    const userCounts: Record<string, number> = {};
    for (const u of Object.values(this.data.userAccounts)) {
      if (u.status === 'ACTIVE') {
        userCounts[u.role] = (userCounts[u.role] || 0) + 1;
      }
    }
    return roles.map((r) => ({
      ...r,
      userCount: userCounts[r.role] || 0,
    } as any));
  }

  public getRoleById(roleId: string): RoleDefinition | undefined {
    return this.data.roles[roleId];
  }

  public saveRole(role: RoleDefinition, actor = 'SUPERADMIN'): RoleDefinition {
    const existing = this.data.roles[role.roleId];
    if (existing?.isSystem && role.role === 'SUPERADMIN' && role.status === 'DISABLED') {
      throw new Error('The system SUPERADMIN role cannot be disabled.');
    }
    role.updatedAt = new Date().toISOString();
    if (!role.createdAt) role.createdAt = new Date().toISOString();
    this.data.roles[role.roleId] = role;
    this.saveDatabase();

    this.addAuditLog({
      actor,
      actorRole: 'SUPERADMIN',
      action: existing ? 'ROLE_UPDATED' : 'ROLE_CREATED',
      result: 'SUCCESS',
      metadata: { roleId: role.roleId, roleName: role.name },
    });

    return role;
  }

  public deleteRole(roleId: string, actor = 'SUPERADMIN'): boolean {
    const role = this.data.roles[roleId];
    if (!role) return false;

    if (role.isSystem) {
      throw new Error(`System role "${role.name}" is protected and cannot be deleted.`);
    }

    // Role deletion must be blocked if active users are still assigned
    const assignedUsers = Object.values(this.data.userAccounts).filter(
      (u) => u.role === role.role && u.status === 'ACTIVE'
    );
    if (assignedUsers.length > 0) {
      throw new Error(
        `Cannot delete role "${role.name}" because ${assignedUsers.length} active user(s) are currently assigned to it. Reassign those users first.`
      );
    }

    delete this.data.roles[roleId];
    this.saveDatabase();

    this.addAuditLog({
      actor,
      actorRole: 'SUPERADMIN',
      action: 'ROLE_DELETED',
      result: 'SUCCESS',
      metadata: { roleId, roleName: role.name },
    });

    return true;
  }

  // --- SETTINGS & VERSIONING ---
  public getSettings(): SystemSettings {
    return { ...this.data.systemSettings };
  }

  public getSettingsVersions(): SettingVersion[] {
    return [...(this.data.settingsVersions || [])].sort((a, b) => b.version - a.version);
  }

  public updateSettings(updates: Partial<SystemSettings>, updatedBy = 'SUPERADMIN'): SystemSettings {
    const current = this.data.systemSettings;
    const versionHistory = this.data.settingsVersions || [];
    let nextVersionNum = versionHistory.length > 0 ? Math.max(...versionHistory.map((v) => v.version)) + 1 : 1;

    for (const [key, newVal] of Object.entries(updates)) {
      const oldVal = (current as any)[key];
      if (oldVal !== newVal && key !== 'updatedAt' && key !== 'updatedBy') {
        const vEntry: SettingVersion = {
          versionId: `VER-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          version: nextVersionNum++,
          settingKey: key,
          oldValue: oldVal,
          newValue: newVal,
          changedBy: updatedBy,
          changedAt: new Date().toISOString(),
          changeType: 'UPDATE',
        };
        versionHistory.unshift(vEntry);

        this.addAuditLog({
          actor: updatedBy,
          actorRole: 'SUPERADMIN',
          action: 'SETTING_CHANGED',
          result: 'SUCCESS',
          metadata: { settingKey: key, oldValue: oldVal, newValue: newVal },
        });
      }
    }

    if (versionHistory.length > 200) {
      this.data.settingsVersions = versionHistory.slice(0, 200);
    } else {
      this.data.settingsVersions = versionHistory;
    }

    this.data.systemSettings = {
      ...this.data.systemSettings,
      ...updates,
      updatedAt: new Date().toISOString(),
      updatedBy,
    };
    this.saveDatabase();
    return this.data.systemSettings;
  }

  public rollbackSetting(versionId: string, actor = 'SUPERADMIN'): { settingKey: string; restoredValue: any } {
    const versionHistory = this.data.settingsVersions || [];
    const entry = versionHistory.find((v) => v.versionId === versionId);
    if (!entry) {
      throw new Error(`Version ${versionId} not found in configuration history.`);
    }

    const { settingKey, oldValue } = entry;
    const currentValue = (this.data.systemSettings as any)[settingKey];

    (this.data.systemSettings as any)[settingKey] = oldValue;
    this.data.systemSettings.updatedAt = new Date().toISOString();
    this.data.systemSettings.updatedBy = actor;

    const rollbackVersion: SettingVersion = {
      versionId: `VER-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      version: (Math.max(...versionHistory.map((v) => v.version), 0)) + 1,
      settingKey,
      oldValue: currentValue,
      newValue: oldValue,
      changedBy: actor,
      changedAt: new Date().toISOString(),
      changeType: 'ROLLBACK',
    };
    versionHistory.unshift(rollbackVersion);
    this.data.settingsVersions = versionHistory;
    this.saveDatabase();

    this.addAuditLog({
      actor,
      actorRole: 'SUPERADMIN',
      action: 'SETTING_ROLLBACK',
      result: 'SUCCESS',
      metadata: { versionId, settingKey, rolledBackTo: oldValue },
    });

    return { settingKey, restoredValue: oldValue };
  }

  // --- RETRY POLICIES ---
  public getRetryPolicies(): RetryPolicy[] {
    return Object.values(this.data.retryPolicies);
  }

  public getRetryPolicyByCode(errorCode: string): RetryPolicy | undefined {
    return Object.values(this.data.retryPolicies).find((p) => p.errorCode === errorCode && p.enabled);
  }

  public saveRetryPolicy(policy: RetryPolicy): RetryPolicy {
    this.data.retryPolicies[policy.policyId] = policy;
    this.saveDatabase();
    return policy;
  }

  // --- APPLICATION ATTEMPTS ---
  public getApplicationAttempts(jobId?: string): ApplicationAttempt[] {
    let list = Object.values(this.data.applicationAttempts);
    if (jobId) {
      list = list.filter((a) => a.jobId === jobId);
    }
    return list.sort((a, b) => b.attemptNo - a.attemptNo);
  }

  public saveApplicationAttempt(attempt: ApplicationAttempt): ApplicationAttempt {
    this.data.applicationAttempts[attempt.attemptId] = attempt;
    this.saveDatabase();
    return attempt;
  }

  // --- AUDIT LOGS ---
  public getAuditLogs(filter?: { jobId?: string; actor?: string; limit?: number }): AuditLog[] {
    let list = [...this.data.auditLogs];
    if (filter?.jobId) {
      list = list.filter((l) => l.jobId === filter.jobId);
    }
    if (filter?.actor) {
      list = list.filter((l) => l.actor === filter.actor);
    }
    list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return list.slice(0, filter?.limit || 100);
  }

  public addAuditLog(log: Omit<AuditLog, 'auditId' | 'timestamp'>): AuditLog {
    const fullLog: AuditLog = {
      auditId: `AUD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      ...log,
    };
    this.data.auditLogs.unshift(fullLog);
    // Keep max 500 logs in memory/disk
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 500);
    }
    this.saveDatabase();
    return fullLog;
  }

  // --- NOTIFICATIONS ---
  public getNotifications(limit = 50): Notification[] {
    return this.data.notifications.slice(0, limit);
  }

  public addNotification(notification: Notification): Notification {
    this.data.notifications.unshift(notification);
    if (this.data.notifications.length > 200) {
      this.data.notifications = this.data.notifications.slice(0, 200);
    }
    this.saveDatabase();
    return notification;
  }

  // --- INTEGRATION STATUS ---
  public getIntegrations(): IntegrationStatusItem[] {
    return Object.values(this.data.integrationStatus);
  }

  public updateIntegrationStatus(id: string, updates: Partial<IntegrationStatusItem>): IntegrationStatusItem {
    if (this.data.integrationStatus[id]) {
      this.data.integrationStatus[id] = {
        ...this.data.integrationStatus[id],
        ...updates,
        lastChecked: new Date().toISOString(),
      };
      this.saveDatabase();
      return this.data.integrationStatus[id];
    }
    const created: IntegrationStatusItem = {
      id,
      name: id,
      status: 'CONNECTED',
      lastChecked: new Date().toISOString(),
      ...updates,
    };
    this.data.integrationStatus[id] = created;
    this.saveDatabase();
    return created;
  }

  // --- SHEET SYNC LOGS ---
  public getSheetSyncLogs(): SheetSyncLog[] {
    return this.data.sheetSyncLogs;
  }

  public addSheetSyncLog(log: SheetSyncLog): SheetSyncLog {
    this.data.sheetSyncLogs.unshift(log);
    if (this.data.sheetSyncLogs.length > 100) {
      this.data.sheetSyncLogs = this.data.sheetSyncLogs.slice(0, 100);
    }
    this.saveDatabase();
    return log;
  }

  // --- STATS / METRICS ---
  public getDashboardMetrics() {
    const jobs = Object.values(this.data.jobs);
    const sessions = Object.values(this.data.sessions);
    const humanTasks = Object.values(this.data.humanTasks);
    const settings = this.data.systemSettings;

    const activeSessions = sessions.filter((s) => s.status === 'RUNNING' || s.status === 'PAUSED' || s.status === 'STARTING').length;
    const capacityLimit = settings.concurrencyLimit;
    const availableCapacity = capacityLimit !== null ? Math.max(0, capacityLimit - activeSessions) : 999;

    return {
      totalJobs: jobs.length,
      queued: jobs.filter((j) => j.status === 'QUEUED' || j.status === 'PREPARING').length,
      running: jobs.filter(
        (j) =>
          j.status === 'BROWSER_STARTING' ||
          j.status === 'BROWSER_READY' ||
          j.status === 'SIGNUP_STARTED' ||
          j.status === 'REGISTRATION_CONTINUING'
      ).length,
      humanActionRequired: humanTasks.filter((t) => t.status === 'OPEN' || t.status === 'ASSIGNED' || t.status === 'IN_PROGRESS').length,
      waitingForReview: jobs.filter((j) => j.status === 'WAITING_FOR_REVIEW').length,
      approved: jobs.filter((j) => j.status === 'APPROVED' || j.status === 'COMPLETED').length,
      rejected: jobs.filter((j) => j.status === 'REJECTED').length,
      errors: jobs.filter((j) => j.status === 'ERROR').length,
      activeSessions,
      availableCapacity: capacityLimit === null ? 'UNLIMITED' : availableCapacity,
      concurrencyLimit: capacityLimit === null ? 'UNLIMITED' : capacityLimit,
      dailyJobLimit: settings.dailyJobLimit === null ? 'UNLIMITED' : settings.dailyJobLimit,
    };
  }

  public resetDemoData() {
    this.data = {
      jobs: Object.fromEntries(initialJobs.map((j) => [j.jobId, { ...j }])),
      sessions: Object.fromEntries(initialSessions.map((s) => [s.sessionId, { ...s }])),
      humanTasks: Object.fromEntries(initialHumanTasks.map((t) => [t.humanTaskId, { ...t }])),
      operators: Object.fromEntries(initialOperators.map((o) => [o.operatorId, { ...o }])),
      userAccounts: this.data.userAccounts || {},
      roles: this.data.roles || {},
      systemSettings: { ...initialSettings },
      settingsVersions: this.data.settingsVersions || [],
      retryPolicies: Object.fromEntries(initialRetryPolicies.map((r) => [r.policyId, { ...r }])),
      applicationAttempts: Object.fromEntries(initialApplicationAttempts.map((a) => [a.attemptId, { ...a }])),
      auditLogs: [...initialAuditLogs],
      notifications: [],
      integrationStatus: Object.fromEntries(initialIntegrations.map((i) => [i.id, { ...i }])),
      sheetSyncLogs: [],
      workflowRuns: {},
    };
    this.saveDatabase();
    return true;
  }
}

export const repository = new Repository();
