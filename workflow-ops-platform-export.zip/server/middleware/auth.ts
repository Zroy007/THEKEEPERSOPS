import { Request, Response, NextFunction } from 'express';
import { repository } from '../db/repository.js';
import { UserRole, Permission } from '../types.js';
import { authService } from '../services/auth.service.js';

export interface AuthContext {
  uid: string;
  operatorId: string;
  name: string;
  email: string;
  role: UserRole;
  mustChangePassword?: boolean;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthContext;
    }
  }
}

export function authMiddleware(req: Request, res: Response, next: NextFunction) {
  // 1. Check for Bearer Token
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7).trim();
    const payload = authService.verifyToken(token);

    if (payload) {
      const account = repository.getUserAccountById(payload.uid, true);
      if (account) {
        if (account.status === 'DISABLED') {
          res.status(403).json({ error: 'Account is disabled. Please contact an administrator.' });
          return;
        }
        if (account.status === 'LOCKED') {
          res.status(403).json({ error: 'Account is locked. Please contact an administrator.' });
          return;
        }

        // Force password change check
        if (account.mustChangePassword) {
          const allowedPaths = ['/api/auth/change-password', '/api/auth/me', '/api/auth/logout'];
          const isAllowed = allowedPaths.some((p) => req.originalUrl.startsWith(p));
          if (!isAllowed) {
            res.status(403).json({
              error: 'Password change required before accessing application functionality.',
              mustChangePassword: true,
            });
            return;
          }
        }

        req.user = {
          uid: account.uid,
          operatorId: account.uid,
          name: account.name,
          email: account.email,
          role: account.role,
          mustChangePassword: account.mustChangePassword,
        };
        next();
        return;
      }
    }
  }

  // 2. Fallback to header-based authentication for dev/test compatibility
  const operatorIdHeader = req.headers['x-operator-id'] as string;
  const roleHeader = req.headers['x-user-role'] as UserRole;

  let operator = operatorIdHeader ? repository.getOperatorById(operatorIdHeader) : undefined;
  if (!operator) {
    const operators = repository.getOperators();
    operator = operators[0]; // Lead Admin default
  }

  const role = roleHeader || operator?.role || 'ADMIN';

  req.user = {
    uid: operator?.operatorId || 'OP-001',
    operatorId: operator?.operatorId || 'OP-001',
    name: operator?.name || 'System Administrator',
    email: operator?.email || 'admin@ops-platform.internal',
    role: role,
    mustChangePassword: false,
  };

  next();
}

export function requireRole(...allowedRoles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized: Authentication required.' });
      return;
    }

    // SUPERADMIN has unconditional access to any role-restricted endpoint
    if (req.user.role === 'SUPERADMIN') {
      next();
      return;
    }

    // ADMIN can access any endpoint unless it strictly requires SUPERADMIN
    if (req.user.role === 'ADMIN' && !allowedRoles.includes('SUPERADMIN')) {
      next();
      return;
    }

    if (!allowedRoles.includes(req.user.role)) {
      res.status(403).json({
        error: `Forbidden: Role ${req.user.role} does not have required permissions [${allowedRoles.join(', ')}]`,
      });
      return;
    }

    next();
  };
}

export function requirePermission(permission: Permission) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized: Authentication required.' });
      return;
    }

    const hasPerm = authService.roleHasPermission(req.user.role, permission, repository.getRoles());
    if (!hasPerm) {
      res.status(403).json({
        error: `Forbidden: Role ${req.user.role} lacks permission "${permission}".`,
      });
      return;
    }

    next();
  };
}

