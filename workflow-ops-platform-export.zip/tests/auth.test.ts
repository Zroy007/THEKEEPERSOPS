import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { requireRole } from '../server/middleware/auth.js';
import { Request, Response } from 'express';

describe('RBAC Middleware & Permissions', () => {
  test('ADMIN role can access any endpoint', () => {
    let nextCalled = false;
    const req = {
      user: { operatorId: 'OP-001', name: 'Admin', email: 'admin@test.org', role: 'ADMIN' },
    } as unknown as Request;

    const res = {
      status: () => res,
      json: () => res,
    } as unknown as Response;

    const middleware = requireRole('SUPERVISOR');
    middleware(req, res, () => {
      nextCalled = true;
    });

    assert.equal(nextCalled, true);
  });

  test('OPERATOR role allowed on OPERATOR endpoint', () => {
    let nextCalled = false;
    const req = {
      user: { operatorId: 'OP-002', name: 'Operator', email: 'op@test.org', role: 'OPERATOR' },
    } as unknown as Request;

    const res = {
      status: () => res,
      json: () => res,
    } as unknown as Response;

    const middleware = requireRole('OPERATOR', 'SUPERVISOR');
    middleware(req, res, () => {
      nextCalled = true;
    });

    assert.equal(nextCalled, true);
  });

  test('VIEWER role blocked with 403 on mutating endpoint', () => {
    let nextCalled = false;
    let statusCode = 0;
    let responseBody: any = null;

    const req = {
      user: { operatorId: 'OP-004', name: 'Viewer', email: 'view@test.org', role: 'VIEWER' },
    } as unknown as Request;

    const res = {
      status: (code: number) => {
        statusCode = code;
        return res;
      },
      json: (data: any) => {
        responseBody = data;
        return res;
      },
    } as unknown as Response;

    const middleware = requireRole('ADMIN', 'SUPERVISOR', 'OPERATOR');
    middleware(req, res, () => {
      nextCalled = true;
    });

    assert.equal(nextCalled, false);
    assert.equal(statusCode, 403);
    assert.ok(responseBody.error.includes('Forbidden'));
  });
});
