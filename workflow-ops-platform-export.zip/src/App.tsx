import React, { useEffect, useState, useCallback } from 'react';
import { api, setActiveOperator } from './services/api';
import {
  Job,
  Session,
  HumanTask,
  Operator,
  UserRole,
  DashboardMetrics,
  SystemSettings,
  RetryPolicy,
  ApplicationAttempt,
  AuditLog,
  SheetSyncLog,
  IntegrationStatusItem,
} from './types';

import { Navbar } from './components/Navbar';
import { Navigation, NavTab } from './components/Navigation';
import { DashboardPage } from './pages/DashboardPage';
import { JobsPage } from './pages/JobsPage';
import { SessionsPage } from './pages/SessionsPage';
import { HumanTasksPage } from './pages/HumanTasksPage';
import { ApplicationsPage } from './pages/ApplicationsPage';
import { SheetsSyncPage } from './pages/SheetsSyncPage';
import { SettingsPage } from './pages/SettingsPage';
import { RetryPoliciesPage } from './pages/RetryPoliciesPage';
import { AuditLogsPage } from './pages/AuditLogsPage';
import { OperatorsPage } from './pages/OperatorsPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { ReportsPage } from './pages/ReportsPage';
import { SystemHealthPage } from './pages/SystemHealthPage';
import { AdminPage } from './pages/AdminPage';
import { AccountsPage } from './pages/AccountsPage';
import { RolesPage } from './pages/RolesPage';
import { SystemSettingsPage } from './pages/SystemSettingsPage';

import { NewJobModal } from './components/NewJobModal';
import { HumanTaskModal } from './components/HumanTaskModal';
import { JobDetailsModal } from './components/JobDetailsModal';
import { BrowserSessionModal } from './components/BrowserSessionModal';
import { LoginModal } from './components/LoginModal';
import { PasswordChangeModal } from './components/PasswordChangeModal';
import { UserAccount } from './types';
import { setAuthToken, getAuthToken } from './services/api';

export default function App() {
  // Navigation & Operator State
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [currentOperatorId, setCurrentOperatorId] = useState('OP-001');
  const [currentRole, setCurrentRole] = useState<UserRole>('SUPERADMIN');

  // Core Data Collections
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [totalJobs, setTotalJobs] = useState(0);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [humanTasks, setHumanTasks] = useState<HumanTask[]>([]);
  const [operators, setOperators] = useState<Operator[]>([]);
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [retryPolicies, setRetryPolicies] = useState<RetryPolicy[]>([]);
  const [attempts, setAttempts] = useState<ApplicationAttempt[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [sheetLogs, setSheetLogs] = useState<SheetSyncLog[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [integrations, setIntegrations] = useState<IntegrationStatusItem[]>([]);
  const [mockMode, setMockMode] = useState(true);

  // Modals & Active Selections
  const [isNewJobOpen, setIsNewJobOpen] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null);

  // Authentication & Super Admin Layer State
  const [loggedInUser, setLoggedInUser] = useState<UserAccount | null>(null);
  const [mustChangePassword, setMustChangePassword] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isPasswordChangeOpen, setIsPasswordChangeOpen] = useState(false);

  // Action states
  const [loading, setLoading] = useState(true);
  const [isProcessingQueue, setIsProcessingQueue] = useState(false);
  const [isSyncingSheets, setIsSyncingSheets] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Check initial authentication
  useEffect(() => {
    const checkAuth = async () => {
      const token = getAuthToken();
      if (!token) return;
      try {
        const me = await api.getMe();
        if (me.user) {
          setLoggedInUser(me.user);
          setMustChangePassword(me.mustChangePassword);
          if (me.mustChangePassword) {
            setIsPasswordChangeOpen(true);
          }
          if (me.user.role === 'SUPERADMIN' || me.user.role === 'ADMIN') {
            setCurrentRole(me.user.role as any);
          }
        }
      } catch (err: any) {
        if (err.mustChangePassword) {
          setMustChangePassword(true);
          setIsPasswordChangeOpen(true);
        } else {
          setAuthToken(null);
        }
      }
    };
    checkAuth();
  }, []);

  // Main data fetcher
  const loadData = useCallback(async () => {
    try {
      const [
        metricsRes,
        jobsRes,
        sessionsRes,
        tasksRes,
        operatorsRes,
        settingsRes,
        policiesRes,
        attemptsRes,
        auditRes,
        sheetLogsRes,
        notifRes,
        healthRes,
      ] = await Promise.allSettled([
        api.getMetrics(),
        api.getJobs({ limit: 100 }),
        api.getSessions(),
        api.getHumanTasks(),
        api.getOperators(),
        api.getSettings(),
        api.getRetryPolicies(),
        api.getAttempts(),
        api.getAuditLogs({ limit: 50 }),
        api.getSheetLogs(),
        api.getNotifications(),
        api.getHealth(),
      ]);

      if (metricsRes.status === 'fulfilled') setMetrics(metricsRes.value);
      if (jobsRes.status === 'fulfilled') {
        setJobs(jobsRes.value.items);
        setTotalJobs(jobsRes.value.total);
      }
      if (sessionsRes.status === 'fulfilled') setSessions(sessionsRes.value);
      if (tasksRes.status === 'fulfilled') setHumanTasks(tasksRes.value);
      if (operatorsRes.status === 'fulfilled') setOperators(operatorsRes.value);
      if (settingsRes.status === 'fulfilled') setSettings(settingsRes.value);
      if (policiesRes.status === 'fulfilled') setRetryPolicies(policiesRes.value);
      if (attemptsRes.status === 'fulfilled') setAttempts(attemptsRes.value);
      if (auditRes.status === 'fulfilled') setAuditLogs(auditRes.value);
      if (sheetLogsRes.status === 'fulfilled') setSheetLogs(sheetLogsRes.value);
      if (notifRes.status === 'fulfilled') setNotifications(notifRes.value);
      if (healthRes.status === 'fulfilled') {
        setMockMode(healthRes.value.mockMode);
        setIntegrations(healthRes.value.integrations);
      }
    } catch (err) {
      console.error('Error loading platform state', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
    // Periodic refresh every 10 seconds for real-time heartbeat and worker updates
    const interval = setInterval(loadData, 10000);
    return () => clearInterval(interval);
  }, [loadData]);

  // Operator Switching
  const handleSelectOperator = (opId: string, role: UserRole) => {
    setCurrentOperatorId(opId);
    setCurrentRole(role);
    setActiveOperator(opId, role);
    showToast(`Active Operator switched to ${opId} (${role})`);
  };

  // Quick Action: Process Queue Worker
  const handleTriggerQueueWorker = async () => {
    setIsProcessingQueue(true);
    try {
      const res = await api.triggerQueueWorker();
      showToast(`Queue processed: ${res.startedJobs} job(s) dispatched into browser sessions.`);
      await loadData();
    } catch (err: any) {
      showToast(`Error processing queue: ${err.message}`);
    } finally {
      setIsProcessingQueue(false);
    }
  };

  // Quick Action: Sheets Sync
  const handleTriggerSyncSheets = async () => {
    setIsSyncingSheets(true);
    try {
      const res = await api.syncSheets();
      showToast(`Google Sheets sync complete: +${res.pulledJobs} pulled, ${res.pushedJobs} updated.`);
      await loadData();
    } catch (err: any) {
      showToast(`Error syncing sheets: ${err.message}`);
    } finally {
      setIsSyncingSheets(false);
    }
  };

  // Job Actions
  const handleCreateJob = async (data: Partial<Job>) => {
    try {
      const newJob = await api.createJob(data);
      showToast(`Job ${newJob.jobId} created and en-queued.`);
      await loadData();
    } catch (err: any) {
      alert(`Error creating job: ${err.message}`);
    }
  };

  const handlePauseJob = async (jobId: string) => {
    try {
      await api.pauseJob(jobId, 'Operator manual pause request');
      showToast(`Job ${jobId} and associated browser session paused.`);
      await loadData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleResumeJob = async (jobId: string) => {
    try {
      await api.resumeJob(jobId);
      showToast(`Job ${jobId} resumed.`);
      await loadData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleRetryJob = async (jobId: string) => {
    try {
      const res = await api.retryJob(jobId);
      showToast(`Technical retry scheduled: ${res.reason}`);
      await loadData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleSubmitJob = async (jobId: string) => {
    try {
      await api.submitJob(jobId);
      showToast(`Application for ${jobId} submitted to merchant review.`);
      await loadData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleReapplyJob = async (jobId: string) => {
    try {
      const res = await api.reapplyJob(jobId);
      showToast(`New attempt #${res.currentAttemptNo} generated for ${jobId}. Historical attempts preserved.`);
      await loadData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleStopSession = async (sessionId: string) => {
    if (!confirm(`Are you sure you want to stop cloud browser session ${sessionId}?`)) return;
    try {
      await api.stopSession(sessionId);
      showToast(`Browser session ${sessionId} stopped.`);
      await loadData();
      if (selectedSessionId === sessionId) setSelectedSessionId(null);
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Human Task Actions
  const handleCompleteHumanTask = async (taskId: string, notes?: string, payload?: Record<string, any>) => {
    try {
      await api.completeHumanTask(taskId, notes, payload);
      showToast(`Human checkpoint ${taskId} verified. Workflow progression resumed.`);
      await loadData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleRemindHumanTask = async (taskId: string) => {
    try {
      await api.remindHumanTask(taskId);
      showToast(`Reminder alert sent to operator via Telegram.`);
      await loadData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleAssignHumanTask = async (taskId: string, operatorId: string) => {
    try {
      await api.assignHumanTask(taskId, operatorId);
      showToast(`Task assigned to ${operatorId}.`);
      await loadData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Settings & Policies
  const handleSaveSettings = async (updates: Partial<SystemSettings>) => {
    const updated = await api.updateSettings(updates);
    setSettings(updated);
    showToast('Platform settings successfully updated.');
    await loadData();
  };

  const handleSavePolicy = async (policyId: string, updates: Partial<RetryPolicy>) => {
    await api.updateRetryPolicy(policyId, updates);
    showToast(`Retry policy ${policyId} updated.`);
    await loadData();
  };

  const handleCreateOperator = async (data: Partial<Operator>) => {
    await api.createOperator(data);
    showToast(`Operator registered.`);
    await loadData();
  };

  // Active items for modals
  const activeHumanTask = humanTasks.find((t) => t.humanTaskId === selectedTaskId);
  const activeSession = sessions.find((s) => s.sessionId === selectedSessionId);

  const openHumanTasksCount = humanTasks.filter(
    (t) => t.status === 'OPEN' || t.status === 'ASSIGNED' || t.status === 'IN_PROGRESS'
  ).length;

  const activeSessionsCount = sessions.filter(
    (s) => s.status === 'RUNNING' || s.status === 'PAUSED'
  ).length;

  return (
    <div className="min-h-screen bg-slate-100/70 flex flex-col text-slate-900 font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl text-xs font-semibold flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header Navbar */}
      <Navbar
        operators={operators}
        currentOperatorId={currentOperatorId}
        currentRole={currentRole}
        metrics={metrics}
        mockMode={mockMode}
        loggedInUser={loggedInUser}
        mustChangePassword={mustChangePassword}
        onSelectOperator={handleSelectOperator}
        onOpenNewJob={() => setIsNewJobOpen(true)}
        onTriggerQueueWorker={handleTriggerQueueWorker}
        onTriggerSyncSheets={handleTriggerSyncSheets}
        onOpenLogin={() => setIsLoginOpen(true)}
        onOpenPasswordChange={() => setIsPasswordChangeOpen(true)}
        onLogout={() => {
          setAuthToken(null);
          setLoggedInUser(null);
          showToast('Signed out successfully.');
        }}
        isProcessingQueue={isProcessingQueue}
      />

      {/* Primary Navigation Tabs */}
      <Navigation
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        humanTasksCount={openHumanTasksCount}
        activeSessionsCount={activeSessionsCount}
        currentRole={currentRole}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {loading && !metrics ? (
          <div className="py-20 text-center">
            <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-xs font-semibold text-slate-500">Connecting to Workflow Engine...</p>
          </div>
        ) : (
          <>
            {activeTab === 'dashboard' && (
              <DashboardPage
                metrics={metrics}
                sessions={sessions}
                humanTasks={humanTasks}
                recentJobs={jobs}
                operators={operators}
                onOpenSession={(s) => setSelectedSessionId(s.sessionId)}
                onOpenHumanTask={(t) => setSelectedTaskId(t.humanTaskId)}
                onSelectJob={(id) => setSelectedJobId(id)}
                onNavigateTab={(tab) => setActiveTab(tab as NavTab)}
                onPauseJob={handlePauseJob}
                onResumeJob={handleResumeJob}
                onRetryJob={handleRetryJob}
                onManualReviewJob={(id) => api.manualReviewJob(id).then(loadData)}
                onStopSession={handleStopSession}
              />
            )}

            {activeTab === 'admin' && <AdminPage />}
            {activeTab === 'accounts' && <AccountsPage currentRole={currentRole} />}
            {activeTab === 'roles' && <RolesPage currentRole={currentRole} />}
            {(activeTab === 'system-settings' || (activeTab === 'settings' && (currentRole === 'SUPERADMIN' || currentRole === 'ADMIN'))) && (
              <SystemSettingsPage currentRole={currentRole} />
            )}

            {activeTab === 'jobs' && (
              <JobsPage
                jobs={jobs}
                operators={operators}
                totalJobs={totalJobs}
                onRefresh={loadData}
                onSelectJob={(id) => setSelectedJobId(id)}
                onOpenNewJob={() => setIsNewJobOpen(true)}
                onPauseJob={handlePauseJob}
                onResumeJob={handleResumeJob}
                onRetryJob={handleRetryJob}
                onSubmitJob={handleSubmitJob}
              />
            )}

            {activeTab === 'sessions' && (
              <SessionsPage
                sessions={sessions}
                operators={operators}
                concurrencyLimit={metrics?.concurrencyLimit ?? 6}
                onRefresh={loadData}
                onOpenSession={(s) => setSelectedSessionId(s.sessionId)}
                onPauseJob={handlePauseJob}
                onResumeJob={handleResumeJob}
                onRetryJob={handleRetryJob}
                onManualReviewJob={(id) => api.manualReviewJob(id).then(loadData)}
                onStopSession={handleStopSession}
                onSelectJob={(id) => setSelectedJobId(id)}
              />
            )}

            {activeTab === 'human-tasks' && (
              <HumanTasksPage
                humanTasks={humanTasks}
                operators={operators}
                onRefresh={loadData}
                onOpenTask={(t) => setSelectedTaskId(t.humanTaskId)}
                onRemindTask={handleRemindHumanTask}
                onAssignTask={handleAssignHumanTask}
                onSelectJob={(id) => setSelectedJobId(id)}
              />
            )}

            {activeTab === 'applications' && (
              <ApplicationsPage
                attempts={attempts}
                operators={operators}
                onSelectJob={(id) => setSelectedJobId(id)}
                onReapplyJob={handleReapplyJob}
              />
            )}

            {activeTab === 'sheets' && (
              <SheetsSyncPage
                logs={sheetLogs}
                jobs={jobs}
                onSync={handleTriggerSyncSheets}
                isSyncing={isSyncingSheets}
              />
            )}

            {activeTab === 'settings' && settings && (
              <SettingsPage settings={settings} onSaveSettings={handleSaveSettings} />
            )}

            {activeTab === 'retry-policies' && (
              <RetryPoliciesPage policies={retryPolicies} onSavePolicy={handleSavePolicy} />
            )}

            {activeTab === 'audit-logs' && <AuditLogsPage logs={auditLogs} />}

            {activeTab === 'operators' && (
              <OperatorsPage operators={operators} onCreateOperator={handleCreateOperator} />
            )}

            {activeTab === 'notifications' && (
              <NotificationsPage
                notifications={notifications}
                onTestNotification={(msg) => api.testNotification(msg).then(loadData)}
              />
            )}

            {activeTab === 'reports' && <ReportsPage metrics={metrics} jobs={jobs} />}

            {activeTab === 'health' && (
              <SystemHealthPage
                integrations={integrations}
                mockMode={mockMode}
                onRefresh={loadData}
                onResetDemoData={() => api.resetDemoData().then(loadData)}
                onTriggerQueueWorker={handleTriggerQueueWorker}
                onTriggerHumanTaskWorker={async () => {
                  const res = await api.triggerHumanTaskWorker();
                  showToast(`Human task check complete: ${res.remindersDispatched} reminder(s) dispatched.`);
                  await loadData();
                }}
                onTriggerReviewWorker={async () => {
                  const res = await api.triggerReviewWorker();
                  showToast(`Review poller complete: ${res.reviewJobsChecked} job(s) checked.`);
                  await loadData();
                }}
              />
            )}
          </>
        )}
      </main>

      {/* MODALS */}
      {/* 1. New Job Modal */}
      {isNewJobOpen && (
        <NewJobModal
          onClose={() => setIsNewJobOpen(false)}
          onCreateJob={handleCreateJob}
        />
      )}

      {/* 2. Human Task Verification Modal */}
      {activeHumanTask && (
        <HumanTaskModal
          task={activeHumanTask}
          operators={operators}
          onClose={() => setSelectedTaskId(null)}
          onComplete={handleCompleteHumanTask}
          onRemind={handleRemindHumanTask}
        />
      )}

      {/* 3. Live Job Details Modal */}
      {selectedJobId && (
        <JobDetailsModal
          jobId={selectedJobId}
          operators={operators}
          onClose={() => setSelectedJobId(null)}
          onRefreshParent={loadData}
          onOpenSession={(s) => setSelectedSessionId(s.sessionId)}
          onOpenHumanTask={(t) => setSelectedTaskId(t.humanTaskId)}
        />
      )}

      {/* 4. Browser Session Cloud Viewer Modal */}
      {activeSession && (
        <BrowserSessionModal
          session={activeSession}
          onClose={() => setSelectedSessionId(null)}
          onPauseJob={handlePauseJob}
          onResumeJob={handleResumeJob}
          onStopSession={handleStopSession}
        />
      )}

      {/* 5. Platform Sign In Modal */}
      <LoginModal
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        onSuccess={(user, mustChange) => {
          setLoggedInUser(user);
          setMustChangePassword(mustChange);
          if (user.role === 'SUPERADMIN' || user.role === 'ADMIN') {
            setCurrentRole(user.role as any);
          }
          showToast(`Signed in successfully as ${user.name} (${user.role})`);
          if (mustChange) {
            setIsPasswordChangeOpen(true);
          }
        }}
      />

      {/* 6. Password Change Modal */}
      <PasswordChangeModal
        isOpen={isPasswordChangeOpen}
        userEmail={loggedInUser?.email || 'zakwanrhmn@gmail.com'}
        isMandatory={mustChangePassword}
        onSuccess={() => {
          setMustChangePassword(false);
          setIsPasswordChangeOpen(false);
          showToast('Password updated securely. Permanent credential active.');
          api.getMe().then((res) => setLoggedInUser(res.user)).catch(() => {});
        }}
        onCancel={!mustChangePassword ? () => setIsPasswordChangeOpen(false) : undefined}
      />
    </div>
  );
}
